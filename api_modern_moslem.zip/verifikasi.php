<?php 

require_once 'connection.php';

 if ($conn) {
 	$username = $_GET['username'];
 	


 	$insert = "UPDATE user SET statusAkun=1 WHERE username='$username'";
 	//$result = mysqli_query($conn,$query);
 	//$response = array();

 

 	if ($username != "") {

 		$result = mysqli_query($conn,$insert);
 		$response = array();


 		if ($result) {
 			array_push($response, array('status' => 'ok'));
 			echo "data berhasil diubah";
 			
 			echo "
		<script>
			alert('pendaftaran sukses');
			document.location.href = 'sambutan.php';
		</script>
		";
 			
 		}
 		else{
 			array_push($response, array('status' => 'gagal di ubah'));
 			echo "data gagal diubah";
 		}
 		# code...
 	}
 	else{
 		array_push($response, array('status' => 'gagal'));
 	}
 }
 else{
 	array_push($response, array('status' => 'gagal konek'));
 }

echo json_encode(array("server_response" => $response));
mysqli_close($conn);
 ?>
 
 