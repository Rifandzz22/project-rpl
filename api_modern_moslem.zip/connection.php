<?php 

	include 'config.php';
	$conn = mysqli_connect(SERVER, USERID, PASSWORD, DB_NAME);

 ?>