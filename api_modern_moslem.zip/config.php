<?php 

define('SERVER', 'localhost');
define('USERID', 'id15442046_userr');
define('PASSWORD', 's?$=G88b^_tu/]+7');
define('DB_NAME', 'id15442046_user');


 ?>