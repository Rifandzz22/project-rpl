<?php 

require_once 'connection.php';

 if ($conn) {
 	$username = $_POST['username'];
 	$email = $_POST['email'];
 	$password = $_POST['password'];
 	$noTelp = (int)$_POST['noTelp'];


 	$insert = "INSERT INTO user(username, email, password, noTelp) VALUES ('$username','$email','$password', '$noTelp')";
 	//$result = mysqli_query($conn,$query);
 	//$response = array();

 

 	if ($username != "" AND $email != "" AND $password != "") {

 		$result = mysqli_query($conn,$insert);
 		$response = array();


 		if ($result) {
 			array_push($response, array('status' => 'ok'));
 		}
 		else{
 			array_push($response, array('status' => 'gagal isi data'));
 		}
 		# code...
 	}
 	else{
 		array_push($response, array('status' => 'gagal'));
 	}
 }
 else{
 	array_push($response, array('status' => 'gagal konek'));
 }

echo json_encode(array("server_response" => $response));
mysqli_close($conn);
 ?>