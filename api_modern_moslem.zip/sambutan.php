
<!DOCTYPE html>
<html>
<head>
	<title>Modern Moslim</title>
	<style type="text/css">
		body{
			text-align: center;
		}
		h1{
			margin-top: 50px;
			color: #8fb895;
		}

		h3{
			margin-top: -10px;
			color: #8fb895;
		}
	</style>
</head>
<body>
	<h1>Selamat Pendaftaran Anda Berhasil</h1>
	<h3>Silahkan Login Di Aplikasi Untuk Melanjutkan</h3>
	<img src="https://i.imgur.com/fv18IAc.png" alt=" Gambar Logo Modern Moeslim">
	<h3 style="margin-top: 20px">CONTACT US : anuanrpl@gmail.com</h3>
</body>
</html>
 
 
 