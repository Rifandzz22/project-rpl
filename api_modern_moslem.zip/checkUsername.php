<?php 

require_once 'connection.php';

 if ($conn) {
 	$username = $_POST['username'];

 	$query = "SELECT * FROM user WHERE username = '$username'";
 	$result = mysqli_query($conn,$query);
 	$response = array();

 	$row = mysqli_num_rows($result);

 	if ($row > 0) {
 		array_push($response, array('status' => 'ok'));
 		# code...
 	}
 	else{
 		array_push($response, array('status' => 'gagal'));
 	}
 }
 else{
 	array_push($response, array('status' => 'gagal konek'));
 }

echo json_encode(array("server_response" => $response));
mysqli_close($conn);
 ?>