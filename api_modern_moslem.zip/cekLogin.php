<?php 

require_once 'connection.php';

 if ($conn) {
 	$username = $_POST['username'];
 	$password = $_POST['password'];

 	$query = "SELECT * FROM user WHERE username = '$username' AND password = '$password' AND statusAkun=1";
 	$result = mysqli_query($conn,$query);
 	$response = array();

 	$row = mysqli_num_rows($result);

 	if ($row > 0) {
 		array_push($response, array('status' => 'ok'));
 		# code...
 	}
 	else{
 	    $query = "SELECT * FROM user WHERE username = '$username' AND password = '$password' AND statusAkun=0";
    	$result2 = mysqli_query($conn,$query);

    	$row2 = mysqli_num_rows($result2);
    	
    	if ($row2 > 0) {
 	    	array_push($response, array('status' => 'tidakTerverif'));
 		    # code...
    	}
    	else{
    	    array_push($response, array('status' => 'gagal'));
    	}
 	    
 		
 	}
 }
 else{
 	array_push($response, array('status' => 'gagal konek'));
 }

echo json_encode(array("server_response" => $response));
mysqli_close($conn);
 ?>